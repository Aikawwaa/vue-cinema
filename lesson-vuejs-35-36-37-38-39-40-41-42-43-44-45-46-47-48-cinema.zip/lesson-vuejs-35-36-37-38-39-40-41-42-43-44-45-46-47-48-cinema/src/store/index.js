import { createStore } from 'vuex'
import upcoming from '@/store/modules/upcoming'
import popular from '@/store/modules/popular'
import infoblock from '@/store/modules/infoblock'
import toprate from '@/store/modules/toprate'
import actors from '@/store/modules/actors'
import cinema from '@/store/modules/cinema'
import search from '@/store/modules/search'
import rec from '@/store/modules/rec'

export default createStore({
  state: {
    apiKey: '83995bd5e7081da6cc1da990a08d3b5d',
    imgUrl: 'https://image.tmdb.org/t/p/w500',
    imgUrlFull: 'https://image.tmdb.org/t/p/original',
  },
  modules: {
    upcoming,
    popular,
    infoblock,
    toprate, 
    actors,
    cinema,
    search,
    rec,
  }
})
