<template>
  <SearchInput/>
</template>

<script>
import SearchInput from '@/components/SearchInput.vue'
export default {
  components: { SearchInput }
}
</script>

