<template>
  <ContentInfo content="movie"/>
</template>

<script>
import ContentInfo from '@/components/ContentInfo.vue'
export default {
  components: {ContentInfo}
}
</script>

