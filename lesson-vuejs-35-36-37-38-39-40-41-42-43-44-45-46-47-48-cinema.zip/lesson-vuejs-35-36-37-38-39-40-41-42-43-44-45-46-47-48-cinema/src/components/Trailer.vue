<template>
    <div class="trailer" :class="{active: id != null}">
        trailer
    </div >
</template>


<script>
export default {
    props: ['category', 'id'],
}
</script>