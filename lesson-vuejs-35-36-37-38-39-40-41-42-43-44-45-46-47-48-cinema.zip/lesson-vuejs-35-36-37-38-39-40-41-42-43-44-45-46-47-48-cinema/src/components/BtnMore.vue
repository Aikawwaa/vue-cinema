<template>
    <router-link :to="`/${page == 'movie' ? 'films' : 'serials'}/` + id" class="btn-more">
        <fa icon="fa-solid fa-bars" /> Подробнее
    </router-link>
</template>

<script>
export default {
    props: ['id', 'page']
}
</script>

